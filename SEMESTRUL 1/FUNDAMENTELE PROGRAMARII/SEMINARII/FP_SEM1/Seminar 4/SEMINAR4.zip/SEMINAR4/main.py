from ui.console import start

start()