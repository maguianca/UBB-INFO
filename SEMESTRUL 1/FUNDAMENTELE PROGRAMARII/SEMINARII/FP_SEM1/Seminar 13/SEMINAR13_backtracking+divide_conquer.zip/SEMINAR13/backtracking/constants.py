VOWELS = ['a','e','i','o','u']
