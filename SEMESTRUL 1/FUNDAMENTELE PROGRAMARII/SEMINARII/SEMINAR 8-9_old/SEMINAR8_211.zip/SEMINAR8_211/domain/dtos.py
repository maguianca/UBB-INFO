# we'll add DTO classes here
# e.g. DTO pentru statistica (cerinta 3): 3.Pentru un client dat, să se afișeze serialele
# cu cele mai bune rating-uri (primele 3). Se va afișa numele clientului, numele serialului, și rating-ul (number_of_stars).
#DTO ClientShow cu fields nume client, nume serial, rating

# SEMINAR 9
# !!! pentru lab sapt. 9 se poate implementa si fara DTO