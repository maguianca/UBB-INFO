import unittest


class TestCaseClientDomain(unittest.TestCase):
    pass
